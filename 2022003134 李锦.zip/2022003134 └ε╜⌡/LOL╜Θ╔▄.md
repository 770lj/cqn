##  LOL游戏介绍

《英雄联盟》（League of Legends，简称LOL）是由美国[拳头游戏](https://baike.baidu.com/item/拳头游戏/24133694?fromModule=lemma_inlink)（Riot Games）开发、中国内地由[腾讯游戏](https://baike.baidu.com/item/腾讯游戏/5950652?fromModule=lemma_inlink)代理运营的英雄对战MOBA竞技网游。游戏里拥有数百个个性英雄，并拥有排位系统、符文系统等特色系统。

《英雄联盟》致力于推动全球电子竞技的发展，除了联动各赛区发展职业联赛、打造电竞体系之外，每年还会举办“[英雄联盟季中冠军赛](https://baike.baidu.com/item/英雄联盟季中冠军赛/20418169?fromModule=lemma_inlink)”、“[英雄联盟全球总决赛](https://baike.baidu.com/item/英雄联盟全球总决赛/15084252?fromModule=lemma_inlink)”、“[英雄联盟全明星赛](https://baike.baidu.com/item/英雄联盟全明星赛/12787385?fromModule=lemma_inlink)”三大世界级赛事，形成了自己独有的电子竞技文化 [1] 。

2018年5月14日，《英雄联盟》加入“[亚洲运动会](https://baike.baidu.com/item/亚洲运动会/2753926?fromModule=lemma_inlink)”，成为表演项目之一 [85] 。2021年11月5日，《英雄联盟》入选为第19届“亚洲运动会”电竞比赛项目，这是电竞首次成为亚运会的正式竞赛项目，向全世界展现电竞运动的魅力，项目所获得的奖牌将计入国家奖牌榜 [99] 。

2019年9月17日，拳头游戏值《英雄联盟》十周年之际发布了其全新的LOGO，并公布每一天全世界都有超过八百万玩家同时在线，这意味着英雄联盟依然是全球玩家数最大的电脑游戏。

![](C:\Users\pejoy\Desktop\2022003134 李锦\picture\201904111730275971.jpg)

LOL的发展趋势：

- 首先要给它下一个定义，英雄联盟是一款电子竞技游戏。不需要回避，就是5V5对抗的游戏，它是DOTA等竞技游戏的延伸和发展。

  ![英雄联盟对电子竞技类体育项目的影响](C:\Users\pejoy\Desktop\2022003134 李锦\picture\2a1ecb460596b814313318b743d246fe464e2278.jpg)

- 电子竞技发展了这么多年，近2-3年到了井喷期。各项国际大赛层出不穷，赛事奖金更是越来越高。对媒体的吸引力也越来越大。

  随着电竞从业人数的增多，电子竞技也形成了自己的生态圈。

  ![英雄联盟对电子竞技类体育项目的影响](C:\Users\pejoy\Desktop\2022003134 李锦\picture\c3c22dbf3bef354f9e5b198a23db574afb321b78.jpg)

- 目前玩英雄联盟的主流人群是中学生到30乃至40岁的人群。

  而英雄联盟职业选手的年龄一般也就是15-23最左右。这就造成了一个与传统相对抗的现象，一群孩子不读书去玩游戏，造孽啊。

  ![英雄联盟对电子竞技类体育项目的影响](C:\Users\pejoy\Desktop\2022003134 李锦\picture\92dd32f7dfb2dc1919cff6af95def4dca1391078.jpg)

- 当然，还有另外一个问题。

  “二十而冠，三十而立，四十不惑”，但是现在的20岁-40岁的人都跑去网吧打游戏，从伦理道德的角度来讲，也是不被接受的，因此引发的家庭矛盾，道德政论也是不绝于耳。

  ![英雄联盟对电子竞技类体育项目的影响](C:\Users\pejoy\Desktop\2022003134 李锦\picture\6834ecc4ec995943e7e2e54a95425d6b05d10478.jpg)

- 抛开舆论的压力。单就电子竞技本身来说，他是一项运动。竞技本身具有不比传统体育项目弱的竞技性，而且他对年轻人更具吸引力。

  ![英雄联盟对电子竞技类体育项目的影响](C:\Users\pejoy\Desktop\2022003134 李锦\picture\bf6e59704618dfda16d8963289214f5792567778.jpg)

- 电子竞技本身倡导的一些价值观也具有正能量，而并非全部是所谓的“沉溺游戏”。

  ![英雄联盟对电子竞技类体育项目的影响](C:\Users\pejoy\Desktop\2022003134 李锦\picture\05e24be983aee8d758ce4e5b6b781431deb66678.jpg)

- 电子竞技形成的经济效益，已经超越了很多传统互联网行业的效益。为年轻人创业提供了很好平台，创造了就业岗位。

  ![英雄联盟对电子竞技类体育项目的影响](C:\Users\pejoy\Desktop\2022003134 李锦\picture\46a92de039723d03a90e9332bb486143d6d45778.jpg)

- 从个人发展的角度来讲，现在的社会每个人都面临着巨大的压力。能够有一款游戏让自己尽情的投入其中，也不失是一种良好的自我调整。

- 首先要给它下一个定义，英雄联盟是一款电子竞技游戏。不需要回避，就是5V5对抗的游戏，它是DOTA等竞技游戏的延伸和发展。

  ![英雄联盟对电子竞技类体育项目的影响](C:\Users\pejoy\Desktop\2022003134 李锦\picture\2a1ecb460596b814313318b743d246fe464e2278.jpg)

- 电子竞技发展了这么多年，近2-3年到了井喷期。各项国际大赛层出不穷，赛事奖金更是越来越高。对媒体的吸引力也越来越大。

  随着电竞从业人数的增多，电子竞技也形成了自己的生态圈。

  ![英雄联盟对电子竞技类体育项目的影响](https://exp-picture.cdn.bcebos.com/c3c22dbf3bef354f9e5b198a23db574afb321b78.jpg?x-bce-process=image%2Fresize%2Cm_lfit%2Cw_500%2Climit_1%2Fformat%2Cf_auto%2Fquality%2Cq_80)

- 目前玩英雄联盟的主流人群是中学生到30乃至40岁的人群。

  而英雄联盟职业选手的年龄一般也就是15-23最左右。这就造成了一个与传统相对抗的现象，一群孩子不读书去玩游戏，造孽啊。

  ![英雄联盟对电子竞技类体育项目的影响](https://exp-picture.cdn.bcebos.com/92dd32f7dfb2dc1919cff6af95def4dca1391078.jpg?x-bce-process=image%2Fresize%2Cm_lfit%2Cw_500%2Climit_1%2Fformat%2Cf_auto%2Fquality%2Cq_80)

- 当然，还有另外一个问题。

  “二十而冠，三十而立，四十不惑”，但是现在的20岁-40岁的人都跑去网吧打游戏，从伦理道德的角度来讲，也是不被接受的，因此引发的家庭矛盾，道德政论也是不绝于耳。

  ![英雄联盟对电子竞技类体育项目的影响](https://exp-picture.cdn.bcebos.com/6834ecc4ec995943e7e2e54a95425d6b05d10478.jpg?x-bce-process=image%2Fresize%2Cm_lfit%2Cw_500%2Climit_1%2Fformat%2Cf_auto%2Fquality%2Cq_80)

- 抛开舆论的压力。单就电子竞技本身来说，他是一项运动。竞技本身具有不比传统体育项目弱的竞技性，而且他对年轻人更具吸引力。

  ![英雄联盟对电子竞技类体育项目的影响](https://exp-picture.cdn.bcebos.com/bf6e59704618dfda16d8963289214f5792567778.jpg?x-bce-process=image%2Fresize%2Cm_lfit%2Cw_500%2Climit_1%2Fformat%2Cf_auto%2Fquality%2Cq_80)

- 电子竞技本身倡导的一些价值观也具有正能量，而并非全部是所谓的“沉溺游戏”。

  ![英雄联盟对电子竞技类体育项目的影响](https://exp-picture.cdn.bcebos.com/05e24be983aee8d758ce4e5b6b781431deb66678.jpg?x-bce-process=image%2Fresize%2Cm_lfit%2Cw_500%2Climit_1%2Fformat%2Cf_auto%2Fquality%2Cq_80)

- 电子竞技形成的经济效益，已经超越了很多传统互联网行业的效益。为年轻人创业提供了很好平台，创造了就业岗位。

  ![英雄联盟对电子竞技类体育项目的影响](https://exp-picture.cdn.bcebos.com/46a92de039723d03a90e9332bb486143d6d45778.jpg?x-bce-process=image%2Fresize%2Cm_lfit%2Cw_500%2Climit_1%2Fformat%2Cf_auto%2Fquality%2Cq_80)

- 从个人发展的角度来讲，现在的社会每个人都面临着巨大的压力。能够有一款游戏让自己尽情的投入其中，也不失是一种良好的自我调整。

  ![](C:\Users\pejoy\Desktop\2022003134 李锦\picture\6b66ce1d23134682bb2ed1d7d41dccc8.jpeg)



